@echo off
setlocal
set GRADLE_VERSION=8.9
set GRADLE_DIR=%USERPROFILE%\.gradle\fir-distributions\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_DIR%\bin\gradle.bat" (
  if not exist "%USERPROFILE%\.gradle\fir-distributions" mkdir "%USERPROFILE%\.gradle\fir-distributions"
  powershell -NoProfile -Command "$u='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $z=Join-Path $env:TEMP 'fir-gradle-%GRADLE_VERSION%.zip'; Invoke-WebRequest $u -OutFile $z; Expand-Archive $z '%USERPROFILE%\.gradle\fir-distributions' -Force"
)
call "%GRADLE_DIR%\bin\gradle.bat" %*
endlocal
