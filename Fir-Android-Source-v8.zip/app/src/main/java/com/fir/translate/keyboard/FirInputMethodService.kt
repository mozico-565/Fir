package com.fir.translate.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.content.res.Configuration
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.fir.translate.core.AppSettings
import com.fir.translate.overlay.BubbleController
import com.fir.translate.translation.TranslationRepository
import com.fir.translate.translation.TranslationResult
import kotlinx.coroutines.*

class FirInputMethodService : InputMethodService() {
    private lateinit var settings: AppSettings
    private lateinit var repository: TranslationRepository
    private lateinit var bubble: BubbleController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var translateJob: Job? = null
    private var root: LinearLayout? = null
    private var suggestion: TextView? = null
    private var replaceButton: Button? = null
    private var lastResult: TranslationResult? = null
    private var lastRequested = ""
    private var language = "ar"
    private var shifted = false
    private var symbols = false
    private var sensitive = false
    private lateinit var palette: KeyboardPalette

    private data class KeyboardPalette(
        val background: Int,
        val key: Int,
        val specialKey: Int,
        val activeKey: Int,
        val text: Int,
        val secondaryText: Int,
        val separator: Int
    )

    override fun onCreate() {
        super.onCreate(); settings = AppSettings(this); repository = TranslationRepository.get(this); bubble = BubbleController(this)
    }

    override fun onCreateInputView(): View = buildKeyboard().also { root = it }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        sensitive = info == null || isSensitive(info)
        if (sensitive) clearTranslation()
    }

    private fun isSensitive(info: EditorInfo): Boolean {
        val type = info.inputType
        val inputClass = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val explicitlyPrivate = info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0
        val password = variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_NUMBER_VARIATION_PASSWORD
        )
        // Numeric/phone/date fields do not need translation and may contain PIN or payment data.
        val nonTextSensitive = inputClass == InputType.TYPE_CLASS_NUMBER ||
            inputClass == InputType.TYPE_CLASS_PHONE || inputClass == InputType.TYPE_CLASS_DATETIME
        return explicitlyPrivate || password || nonTextSensitive
    }

    private fun buildKeyboard(): LinearLayout = LinearLayout(this).apply {
        palette = resolvePalette()
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        setPadding(6.dp, 4.dp, 6.dp, 6.dp)
        setBackgroundColor(palette.background)
        if (settings.glassKeyboard) background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF401C25.toInt(), 0xFF41432C.toInt(), 0xFF082F2B.toInt())
        )
        addView(buildSuggestionBar())
        if (settings.showSizeControls) addView(LinearLayout(this@FirInputMethodService).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(key("−", special = true) { settings.keyHeight -= 4; rebuild() }, params(44))
            addView(TextView(context).apply { text = "حجم لوحة المفاتيح"; gravity = Gravity.CENTER; setTextColor(palette.secondaryText) }, LinearLayout.LayoutParams(0, 36.dp, 1f))
            addView(key("+", special = true) { settings.keyHeight += 4; rebuild() }, params(44))
        })
        currentRows().forEachIndexed { index, row -> addView(buildRow(row, index)) }
        addView(buildBottomRow())
    }

    private fun buildSuggestionBar() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(10.dp, 2.dp, 2.dp, 2.dp)
        setBackgroundColor(if (settings.glassKeyboard) Color.TRANSPARENT else palette.background)
        suggestion = TextView(context).apply {
            text = "Fir   عربي → English"
            setTextColor(palette.secondaryText)
            textSize = 13f
            maxLines = 2
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        addView(suggestion, LinearLayout.LayoutParams(0, 42.dp, 1f))
        replaceButton = key("Replace", palette.activeKey, special = true) { replaceCurrent() }.apply { visibility = View.GONE }
        addView(replaceButton, LinearLayout.LayoutParams(76.dp, 38.dp).apply { setMargins(2.dp, 2.dp, 2.dp, 2.dp) })
        addView(key("×", Color.TRANSPARENT, special = true) { clearTranslation() }, LinearLayout.LayoutParams(42.dp, 38.dp))
    }

    private fun currentRows() = when { symbols -> KeyboardLayout.numbers; language == "ar" -> KeyboardLayout.arabic; else -> KeyboardLayout.english }
    private fun buildRow(chars: List<String>, rowIndex: Int) = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        if (!symbols && language == "en" && rowIndex == 2) {
            addView(key(if (shifted) "⇧" else "⇧", if (shifted) palette.activeKey else palette.specialKey, special = true) { shifted = !shifted; rebuild() }, params(48))
        }
        chars.forEach { ch ->
            addView(
                key(if (shifted && language == "en") ch.uppercase() else ch) { commitKey(ch) },
                LinearLayout.LayoutParams(0, settings.keyHeight.dp, 1f).apply { setMargins(2.dp, 4.dp, 2.dp, 4.dp) }
            )
        }
        if (rowIndex == 2) {
            addView(key("⌫", special = true) { currentInputConnection?.deleteSurroundingText(1, 0); typed() }, params(50))
        }
    }
    private fun buildBottomRow() = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        addView(key(if (symbols) "ABC" else "123", special = true) { symbols = !symbols; rebuild() }, params(54))
        addView(key("◉", special = true) { language = if (language == "ar") "en" else "ar"; symbols = false; rebuild() }, params(46))
        addView(key(if (language == "ar") "العربية" else "English") { currentInputConnection?.commitText(" ", 1); typed() }, LinearLayout.LayoutParams(0, settings.keyHeight.dp, 1f).apply { setMargins(3.dp,3.dp,3.dp,3.dp) })
        addView(key(".", special = true) { currentInputConnection?.commitText(".", 1); typed() }, params(42))
        addView(key(if (language == "ar") "إدخال" else "return", palette.activeKey, special = true) { currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)); clearTranslation() }, params(60))
    }

    private fun params(width: Int) = LinearLayout.LayoutParams(width.dp, settings.keyHeight.dp).apply { setMargins(2.dp,4.dp,2.dp,4.dp) }
    private fun key(label: String, color: Int? = null, special: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = when { label.length == 1 -> 21f; label in listOf("return", "إدخال", "space", "مسافة") -> 11f; else -> 12f }
        typeface = Typeface.create("sans", Typeface.NORMAL)
        if (label == "⇧") { text = "⬆"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD }
        setTextColor(if (settings.glassKeyboard) Color.WHITE else palette.text)
        isAllCaps = false
        includeFontPadding = false
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        stateListAnimator = null
        elevation = if (special) 0.5f.dp else 1.5f.dp
        background = android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x448AB4F8), bg(color ?: if (special) palette.specialKey else palette.key, 9f.dp), null)
        if (settings.glassKeyboard) {
            val blue = label in listOf("return", "إدخال")
            val glassFace = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if (blue) intArrayOf(0xFF8CCAFF.toInt(), 0xFF2476E7.toInt(), 0xFF70B2FF.toInt())
                else intArrayOf(0xBBDDE4E8.toInt(), 0x555B6670, 0x887D9294.toInt())
            ).apply { cornerRadius = if (blue) 32f.dp else 15f.dp; setStroke(1.dp.coerceAtLeast(1), 0xBBDDFFFF.toInt()) }
            background = android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x66FFFFFF), glassFace, null)
            elevation = 3f.dp
        }
        setSingleLine(true)
        var preview: android.widget.PopupWindow? = null
        var repeatJob: Job? = null
        var repeated = false
        setOnTouchListener { view, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    repeated = false
                    if (label == "⌫") {
                        repeatJob?.cancel()
                        repeatJob = scope.launch {
                            delay(350)
                            repeated = true
                            while (isActive && view.isAttachedToWindow && isInputViewShown) {
                                click()
                                delay(65)
                            }
                        }
                    }
                    view.animate().scaleX(.96f).scaleY(.94f).setDuration(45).start()
                    if (!special && label.length == 1) {
                        val caption = TextView(context).apply { text = label; textSize = 30f; gravity = Gravity.CENTER; setTextColor(palette.text); background = bg(palette.specialKey, 12f.dp) }
                        preview = android.widget.PopupWindow(caption, 54.dp, 66.dp, false).apply { isClippingEnabled = true }
                        runCatching { preview?.showAsDropDown(view, (view.width - 54.dp) / 2, -view.height - 66.dp) }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    repeatJob?.cancel(); repeatJob = null
                    preview?.dismiss(); preview = null
                    view.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (event.x < 0 || event.x >= view.width || event.y < 0 || event.y >= view.height) {
                        repeatJob?.cancel(); repeatJob = null
                    }
                }
            }
            false
        }
        addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { repeatJob?.cancel(); repeatJob = null; preview?.dismiss(); preview = null }
        })
        setPadding(1.dp, 0, 1.dp, 0)
        setOnClickListener { if (label != "⌫" || !repeated) { feedback(); click() } }
    }
    private fun commitKey(raw: String) { val out = if (shifted && language == "en") raw.uppercase() else raw; currentInputConnection?.commitText(out, 1); if (shifted) shifted = false; typed() }
    private fun typed() = scheduleTranslation(false)

    private fun scheduleTranslation(immediate: Boolean) {
        if (sensitive) return
        translateJob?.cancel()
        translateJob = scope.launch {
            if (!immediate) delay(settings.delay.millis)
            val source = currentSegment()
            if (source == lastRequested || !repository.isWorthTranslating(source)) { if (source.isBlank()) clearTranslation(); return@launch }
            lastRequested = source
            try {
                val result = withContext(Dispatchers.Default) { repository.translate(source, settings.direction) }
                if (currentSegment() == source) showTranslation(result)
            } catch (_: Exception) {
                suggestion?.text = "Offline translation model required"
                replaceButton?.visibility = View.GONE
            }
        }
    }

    private fun currentSegment(): String {
        val before = currentInputConnection?.getTextBeforeCursor(500, 0)?.toString().orEmpty()
        return before.substringAfterLast('\n').trimStart()
    }
    private fun showTranslation(result: TranslationResult) {
        lastResult = result; suggestion?.text = result.translated; replaceButton?.visibility = View.VISIBLE
        if (settings.bubbleEnabled && bubble.canShow()) bubble.show(result.translated, ::replaceCurrent) { copy(result.translated) }
    }
    private fun replaceCurrent() {
        val result = lastResult ?: return
        currentInputConnection?.run {
            beginBatchEdit()
            deleteSurroundingText(result.source.length, 0)
            commitText(result.translated, 1)
            endBatchEdit()
        }
        clearTranslation()
    }
    private fun copy(text: String) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Fir translation", text)); bubble.hide() }
    private fun clearTranslation() { translateJob?.cancel(); lastResult = null; lastRequested = ""; suggestion?.text = "Fir • ${if (language == "ar") "عربي → English" else "English → عربي"}"; replaceButton?.visibility = View.GONE; bubble.hide() }
    private fun rebuild() { setInputView(buildKeyboard().also { root = it }); clearTranslation() }
    private fun feedback() {
        if (settings.vibration) runCatching {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(12, 35))
                else @Suppress("DEPRECATION") vibrator.vibrate(12)
            }
        }
        if (settings.sound) runCatching {
            (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEY_CLICK, 0.18f)
        }
    }
    private fun bg(color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun resolvePalette(): KeyboardPalette {
        val systemDark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        val dark = settings.theme == com.fir.translate.core.ThemeMode.DARK ||
            settings.theme == com.fir.translate.core.ThemeMode.SYSTEM && systemDark
        return if (dark) KeyboardPalette(
            background = 0xFF1C1C1E.toInt(), key = 0xFF5A5A5E.toInt(), specialKey = 0xFF3A3A3C.toInt(),
            activeKey = 0xFF2D8C8F.toInt(), text = Color.WHITE, secondaryText = 0xFFE5E5EA.toInt(), separator = 0xFF2C2C2E.toInt()
        ) else KeyboardPalette(
            background = 0xFFD1D5DB.toInt(), key = 0xFFFDFDFE.toInt(), specialKey = 0xFFAEB3BC.toInt(),
            activeKey = 0xFF57D2D1.toInt(), text = 0xFF111111.toInt(), secondaryText = 0xFF3A3A3C.toInt(), separator = 0xFFB8BDC5.toInt()
        )
    }
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp get() = this * resources.displayMetrics.density
    override fun onFinishInputView(finishingInput: Boolean) { clearTranslation(); super.onFinishInputView(finishingInput) }
    override fun onDestroy() { scope.cancel(); bubble.hide(); super.onDestroy() }
}
