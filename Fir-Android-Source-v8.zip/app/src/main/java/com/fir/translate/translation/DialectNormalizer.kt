package com.fir.translate.translation

import com.fir.translate.core.Dialect

/** Small offline vocabulary aid, not a dialect language model. Never modifies editor text. */
object DialectNormalizer {
    private val sudanese = mapOf(
        "كيفنك" to "كيف حالك", "كيفنكم" to "كيف حالكم",
        "داير" to "أريد", "دايرة" to "أريد", "عايز" to "أريد", "عايزة" to "أريد",
        "شنو" to "ماذا", "وين" to "أين", "هسي" to "الآن", "هسع" to "الآن",
        "بكرة" to "غدا", "كويس" to "جيد", "كويسة" to "جيدة",
        "زول" to "شخص", "زولة" to "امرأة",
        "ديل" to "هؤلاء", "دا" to "هذا", "دي" to "هذه", "موية" to "ماء"
    )
    private val saudi = mapOf(
        "وش" to "ماذا", "ايش" to "ماذا", "إيش" to "ماذا",
        "أبغى" to "أريد", "ابغى" to "أريد",
        "الحين" to "الآن", "دحين" to "الآن", "بكرة" to "غدا",
        "وين" to "أين", "ليش" to "لماذا", "كيفك" to "كيف حالك",
        "شلونك" to "كيف حالك", "هذي" to "هذه", "هذولي" to "هؤلاء",
        "موية" to "ماء", "يبغى" to "يريد", "تبغى" to "تريد"
    )
    private val word = Regex("[\\p{L}\\p{M}]+")
    fun normalize(text: String, dialect: Dialect): String {
        val words = when (dialect) {
            Dialect.STANDARD -> return text
            Dialect.SUDANESE -> sudanese
            Dialect.SAUDI -> saudi
        }
        // Phrase rules preserve negation and avoid changing ambiguous standalone words.
        val phrases = when (dialect) {
            Dialect.SUDANESE -> listOf(
                "ما داير" to "لا أريد", "ما دايرة" to "لا أريد", "ما عايز" to "لا أريد",
                "أنا داير" to "أنا أريد", "انت داير" to "أنت تريد", "إنت داير" to "أنت تريد",
                "هو داير" to "هو يريد", "هي دايرة" to "هي تريد",
                "كويس شديد" to "جيد جدا", "تعبان شديد" to "متعب جدا"
            )
            Dialect.SAUDI -> listOf(
                "ما أبغى" to "لا أريد", "ما ابغى" to "لا أريد", "ما أبي" to "لا أريد",
                "أبي أروح" to "أريد أن أذهب", "أبي اروح" to "أريد أن أذهب",
                "وش رايك" to "ما رأيك", "وش رأيك" to "ما رأيك", "مره حلو" to "جميل جدا"
            )
            else -> emptyList()
        }
        var prepared = text
        for ((phrase, replacement) in phrases) {
            val pattern = Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(phrase) + "(?![\\p{L}\\p{M}])")
            prepared = pattern.replace(prepared, replacement)
        }
        return word.replace(prepared) { words[it.value] ?: it.value }
    }
}
