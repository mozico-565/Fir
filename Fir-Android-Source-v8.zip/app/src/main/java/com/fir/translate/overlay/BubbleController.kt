package com.fir.translate.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BubbleController(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    fun canShow() = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)

    fun show(text: String, onReplace: () -> Unit, onCopy: () -> Unit) {
        if (!canShow()) return
        hide()
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 18, 18, 12)
            background = roundedDrawable(0xEE102126.toInt(), 28f)
        }
        box.addView(TextView(context).apply { this.text = text; setTextColor(Color.WHITE); textSize = 15f })
        box.addView(LinearLayout(context).apply {
            gravity = Gravity.END
            addView(action("Replace") { onReplace() })
            addView(action("Copy") { onCopy() })
            addView(action("×") { hide() })
        })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 340
        }
        wm.addView(box, params); view = box
    }

    private fun action(label: String, click: () -> Unit) = Button(context).apply {
        text = label; textSize = 11f; minWidth = 0; minimumWidth = 0; setTextColor(0xFF35D6D1.toInt()); setBackgroundColor(Color.TRANSPARENT)
        setOnClickListener { click() }
    }
    private fun roundedDrawable(color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius }
    fun hide() { view?.let { runCatching { wm.removeView(it) } }; view = null }
}
