package com.fir.translate.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fir.translate.core.ThemeMode

private val Dark = darkColorScheme(primary = Color(0xFF35D6D1), background = Color(0xFF071014), surface = Color(0xFF102126), onBackground = Color(0xFFE7F2F4))
private val Light = lightColorScheme(primary = Color(0xFF007F82), background = Color(0xFFF4F8F8), surface = Color.White, onBackground = Color(0xFF102126))

@Composable fun FirTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = mode == ThemeMode.DARK || mode == ThemeMode.SYSTEM && isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Typography(), content = content)
}
