package com.fir.translate

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fir.translate.core.*
import com.fir.translate.translation.*
import com.fir.translate.ui.FirTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appSettings = AppSettings(this)
        setContent { var tick by remember { mutableIntStateOf(0) }; FirTheme(appSettings.theme) { FirApp(appSettings, tick) { tick++ } } }
    }

    @Composable private fun FirApp(prefs: AppSettings, tick: Int, refresh: () -> Unit) {
        var screen by remember { mutableStateOf(if (prefs.onboardingDone) "home" else "onboarding") }
        when(screen) {
            "onboarding" -> Onboarding { prefs.onboardingDone = true; screen = "home" }
            "settings" -> SettingsPage(prefs, refresh) { screen = "home" }
            "playground" -> Playground { screen = "home" }
            else -> Home { screen = it }
        }
    }

    @Composable private fun Onboarding(done: () -> Unit) {
        var step by remember { mutableIntStateOf(0) }
        val titles = listOf("Welcome to Fir", "Enable Fir Keyboard", "Select Fir Keyboard", "Download Offline Translation", "Floating Bubble (Optional)", "Test it")
        val bodies = listOf("ترجمة لحظية خاصة أثناء الكتابة.", "فعّل Fir من قائمة لوحات المفاتيح.", "اختر Fir Keyboard عند الكتابة.", "نزّل حزم العربية والإنجليزية مرة واحدة.", "يمكن عرض اقتراح عائم، والشريط داخل الكيبورد يعمل دائمًا.", "افتح Fir Playground وجرب الترجمة.")
        Screen(title = "Fir • ${step + 1}/6") {
            Spacer(Modifier.weight(1f)); Text(titles[step], style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text(bodies[step]); Spacer(Modifier.weight(1f))
            Button(onClick = { if (step < 5) step++ else done() }, modifier = Modifier.fillMaxWidth()) { Text(if(step < 5) "Continue" else "Open Fir") }
            if (step > 0) TextButton(onClick = { step-- }, modifier = Modifier.fillMaxWidth()) { Text("Back") }
        }
    }

    @Composable private fun Home(go: (String) -> Unit) {
        val repo = remember { TranslationRepository.get(this) }
        val status by repo.status.collectAsStateWithLifecycle()
        val scope = rememberCoroutineScope()
        Screen("Fir") {
            Text("LIVE TRANSLATE", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp)); StatusCard("Fir Keyboard", if (isKeyboardEnabled()) "Enabled" else "Disabled")
            StatusCard("Arabic → English", status.name); StatusCard("English → Arabic", status.name)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable Fir Keyboard") }
            OutlinedButton(onClick = { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }, modifier = Modifier.fillMaxWidth()) { Text("Select Fir Keyboard") }
            OutlinedButton(onClick = { scope.launch { repo.downloadModels() } }, enabled = status != ModelStatus.DOWNLOADING, modifier = Modifier.fillMaxWidth()) { Text(if(status == ModelStatus.DOWNLOADING) "Downloading…" else "Download Language Models") }
            OutlinedButton(onClick = { go("playground") }, modifier = Modifier.fillMaxWidth()) { Text("Fir Playground") }
            TextButton(onClick = { go("settings") }, modifier = Modifier.fillMaxWidth()) { Text("Settings") }
        }
    }

    private fun isKeyboardEnabled(): Boolean = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_INPUT_METHODS)?.contains(packageName) == true

    @Composable private fun StatusCard(label: String, value: String) { Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text(value, color = MaterialTheme.colorScheme.primary) } } }

    @Composable private fun Playground(back: () -> Unit) {
        val repo = remember { TranslationRepository.get(this) }; val scope = rememberCoroutineScope(); var original by remember { mutableStateOf("") }; var translated by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
        Screen("Fir Playground", back) {
            OutlinedTextField(original, { original = it }, label = { Text("Original") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Button(onClick = { scope.launch { runCatching { repo.translate(original, Direction.AUTO) }.onSuccess { translated = it.translated; error = "" }.onFailure { error = "نزّل نماذج الترجمة أولًا" } } }, modifier = Modifier.fillMaxWidth()) { Text("Translate Offline") }
            OutlinedTextField(translated, { translated = it }, label = { Text("Translation") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            OutlinedButton(onClick = { original = translated; translated = "" }, enabled = translated.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Replace") }
        }
    }

    @Composable private fun SettingsPage(prefs: AppSettings, refresh: () -> Unit, back: () -> Unit) {
        Screen("Settings", back) {
            EnumChoice("Translation Direction", Direction.entries, prefs.direction) { prefs.direction = it; refresh() }
            Toggle("Floating Bubble", prefs.bubbleEnabled) { enabled -> prefs.bubbleEnabled = enabled; if (enabled && !Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))); refresh() }
            EnumChoice("Translation delay", Delay.entries, prefs.delay) { prefs.delay = it; refresh() }
            Toggle("Vibration", prefs.vibration) { prefs.vibration = it; refresh() }
            Toggle("Sound", prefs.sound) { prefs.sound = it; refresh() }
            EnumChoice("Theme", ThemeMode.entries, prefs.theme) { prefs.theme = it; refresh() }
            Text("Bubble position: Above keyboard. Near-field positioning is not reliable across all Android apps without Accessibility.", style = MaterialTheme.typography.bodySmall)
        }
    }

    @Composable private fun <T: Enum<T>> EnumChoice(title: String, values: List<T>, selected: T, choose: (T) -> Unit) { Text(title, fontWeight = FontWeight.Bold); Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { values.forEach { FilterChip(selected == it, { choose(it) }, { Text(it.name.replace('_',' '), style = MaterialTheme.typography.labelSmall) }) } } }
    @Composable private fun Toggle(title: String, checked: Boolean, change: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text(title); Switch(checked, change) } }
    @Composable private fun Screen(title: String, back: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) { Scaffold(topBar = { if(back != null) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = back) { Text("Back") }; Text(title, style = MaterialTheme.typography.titleLarge) } } }) { pad -> Column(Modifier.fillMaxSize().padding(pad).padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp), content = content) } }
}
