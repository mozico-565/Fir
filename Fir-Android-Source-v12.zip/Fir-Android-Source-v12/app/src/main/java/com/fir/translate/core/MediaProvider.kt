package com.fir.translate.core

import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Reads recent screenshots from the device gallery so the keyboard can offer them for pasting. */
object MediaProvider {
    fun recentScreenshots(context: Context, limit: Int = 12): List<Uri> {
        val uris = mutableListOf<Uri>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val selection = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%screenshot%")
        val sort = "${MediaStore.Images.Media.DATE_ADDED} DESC LIMIT $limit"
        runCatching {
            context.contentResolver.query(collection, projection, selection, args, sort)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                while (cursor.moveToNext()) {
                    uris.add(Uri.withAppendedPath(collection, cursor.getLong(idCol).toString()))
                }
            }
        }
        return uris
    }
}
