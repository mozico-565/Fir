# Fir — ترجمة لحظية أثناء الكتابة

الإصدار **1.1.0 (v9)** يضيف شعار Fir الزجاجي الجديد، أيقونة التطبيق الجديدة، وهوية موحدة بالزمردي والسماوي في الوضعين الداكن والفاتح.

Fir تطبيق Android Native مكتوب بـ Kotlin. يوفر لوحة مفاتيح عربية/إنجليزية، ويترجم النص الذي يكتبه المستخدم محليًا عبر ML Kit، ثم يسمح باستبداله فورًا داخل التطبيق الحالي.

## فتح وتشغيل المشروع

1. افتح Android Studio واختر **Open** ثم مجلد `Fir`.
2. انتظر Gradle Sync. يحتاج المشروع JDK 17 وAndroid SDK 35.
3. شغّل التطبيق على هاتف Android 8 أو أحدث.

## بناء APK

- Debug: من Android Studio اختر **Build > Build APK(s)**. الملف في `app/build/outputs/apk/debug/app-debug.apk`.
- Release تجريبي قابل للتثبيت: شغّل `./gradlew assembleRelease`. الملف في `app/build/outputs/apk/release/app-release.apk`.
- للنشر في Google Play، استبدل توقيع debug في `app/build.gradle.kts` بمفتاح Release خاص بك.

## بناء APK من الجوال فقط

المشروع يحتوي workflow جاهزًا في `.github/workflows/build-apk.yml`:

1. ارفع ملفات المشروع إلى مستودع GitHub واجعل الفرع الرئيسي اسمه `main`.
2. افتح تبويب **Actions** ثم **Build Fir APK**.
3. اضغط **Run workflow**.
4. بعد اكتمال البناء افتح التشغيل الأخير، ثم نزّل ملف **Fir-APKs** من قسم Artifacts.
5. فك الضغط على الجوال وثبّت `app-debug.apk`.

GitHub Actions ينزّل Java وGradle وAndroid SDK في السحابة، لذلك لا تحتاج Android Studio على الجوال.

## تفعيل Fir Keyboard

1. افتح Fir واضغط **Enable Fir Keyboard**.
2. فعّل **Fir Keyboard** من إعدادات النظام.
3. ارجع واضغط **Select Fir Keyboard** واختر Fir.

## تنزيل الترجمة المحلية

من الشاشة الرئيسية اضغط **Download Language Models**. يلزم الإنترنت أول مرة فقط. بعد ظهور `READY` تعمل العربية ↔ الإنجليزية دون إنترنت.

## Bubble

من Settings فعّل **Floating Bubble** ثم وافق على إذن الظهور فوق التطبيقات. إذا لم تمنح الإذن، يظل اقتراح الترجمة ظاهرًا داخل أعلى الكيبورد. موضع Bubble الحالي فوق الكيبورد لأن تحديد حقل الكتابة بدقة في كل التطبيقات يحتاج Accessibility، وFir لا يطلبه حفاظًا على الخصوصية.

## الخصوصية

- لا توجد خوادم أو API keys.
- النص مؤقت في الذاكرة فقط، والـLRU cache غير دائم.
- حقول Password وPIN والأرقام والهاتف والتاريخ محمية: لا ترجمة ولا Bubble. يتم كذلك احترام علامة `NO_PERSONALIZED_LEARNING` التي تستخدمها التطبيقات للحقول الخاصة.
- صلاحيات الإنترنت (لتنزيل النموذج)، والاهتزاز، وOverlay الاختياري فقط.

## تغيير الألوان

ألوان التطبيق في `app/src/main/java/com/fir/translate/ui/FirTheme.kt`، وألوان الكيبورد في `keyboard/FirInputMethodService.kt`.

## إضافة لغة

1. أضف اتجاهًا جديدًا إلى `Direction`.
2. أنشئ Translator جديدًا في `TranslationRepository`.
3. أضف تنزيل النموذج إلى `downloadModels()`.
4. أضف تخطيط الأحرف إلى `KeyboardLayout` وزر اختيار اللغة.

## أهم الملفات

- `keyboard/FirInputMethodService.kt`: الكيبورد، قراءة النص، debounce، الاستبدال.
- `translation/TranslationRepository.kt`: ML Kit، اكتشاف اللغة، تنزيل النماذج، LRU cache.
- `overlay/BubbleController.kt`: الغيمة الاختيارية.
- `MainActivity.kt`: Onboarding وHome وSettings وPlayground.
- `core/AppSettings.kt`: إعدادات Fir المحلية.

## ملاحظات النسخة الأولى

- Replace يستبدل النص من بداية السطر الحالي حتى موضع المؤشر. بعض الحقول المحمية أو التطبيقات قد تمنع `InputConnection` من إرجاع النص؛ عندها لا تظهر الترجمة.
- حقول بطاقات الدفع لا تملك معيار Android موحدًا يمكن للكيبورد اكتشافه في كل التطبيقات؛ لذلك يعطل Fir الترجمة في جميع الحقول الرقمية والهاتفية، إضافةً إلى Password/PIN والحقول التي يعلّمها التطبيق بأنها خاصة.
