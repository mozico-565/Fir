package com.fir.translate.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fir.translate.core.ThemeMode

private val Dark = darkColorScheme(
    primary = Color(0xFF45E0D0), secondary = Color(0xFF58A6FF),
    background = Color(0xFF050A0D), surface = Color(0xFF0D171C),
    surfaceVariant = Color(0xFF14262D), onPrimary = Color(0xFF00201E),
    onBackground = Color(0xFFEAF7F7), onSurface = Color(0xFFEAF7F7),
    outline = Color(0xFF45616A)
)
private val Light = lightColorScheme(
    primary = Color(0xFF007F78), secondary = Color(0xFF1769AA),
    background = Color(0xFFF2F8F8), surface = Color.White,
    surfaceVariant = Color(0xFFDDEDEC), onPrimary = Color.White,
    onBackground = Color(0xFF071416), onSurface = Color(0xFF071416),
    outline = Color(0xFF718B8E)
)

@Composable fun FirTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = mode == ThemeMode.DARK || mode == ThemeMode.SYSTEM && isSystemInDarkTheme()
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = Typography(), content = content)
}
