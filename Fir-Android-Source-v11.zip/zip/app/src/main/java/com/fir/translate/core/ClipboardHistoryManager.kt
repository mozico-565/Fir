package com.fir.translate.core

import android.content.Context
import org.json.JSONArray

/**
 * Persists clipboard text: a rolling recent history (auto-evicted once full) plus a
 * separate pinned list that is never auto-evicted and survives "clear all".
 */
class ClipboardHistoryManager(context: Context) {
    private val prefs = context.getSharedPreferences("fir_clipboard_history", Context.MODE_PRIVATE)
    private val maxItems = 20
    private val maxPinned = 10

    fun all(): List<String> = readList(KEY_ITEMS)
    fun pinned(): List<String> = readList(KEY_PINNED)
    fun isPinned(text: String) = pinned().contains(text.trim())

    fun add(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || isPinned(trimmed)) return
        val current = all().toMutableList()
        current.remove(trimmed)
        current.add(0, trimmed)
        while (current.size > maxItems) current.removeAt(current.lastIndex)
        writeList(KEY_ITEMS, current)
    }

    fun remove(text: String) {
        writeList(KEY_ITEMS, all().toMutableList().apply { remove(text) })
    }

    /** Moves an item between the recent list and the pinned list. */
    fun togglePin(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val pins = pinned().toMutableList()
        if (pins.remove(trimmed)) {
            writeList(KEY_PINNED, pins)
            add(trimmed)
        } else {
            pins.add(0, trimmed)
            while (pins.size > maxPinned) pins.removeAt(pins.lastIndex)
            writeList(KEY_PINNED, pins)
            remove(trimmed)
        }
    }

    fun removePinned(text: String) {
        writeList(KEY_PINNED, pinned().toMutableList().apply { remove(text) })
    }

    /** Clears recent history only — pinned items are kept on purpose. */
    fun clear() {
        writeList(KEY_ITEMS, emptyList())
    }

    private fun readList(key: String): List<String> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return (0 until arr.length()).map { arr.getString(it) }
    }

    private fun writeList(key: String, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private companion object {
        const val KEY_ITEMS = "items"
        const val KEY_PINNED = "pinned"
    }
}
