package com.fir.translate.keyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.content.res.Configuration
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.fir.translate.core.AppSettings
import com.fir.translate.core.ClipboardHistoryManager
import com.fir.translate.overlay.BubbleController
import com.fir.translate.translation.TranslationRepository
import com.fir.translate.translation.TranslationResult
import kotlinx.coroutines.*

class FirInputMethodService : InputMethodService() {
    private lateinit var settings: AppSettings
    private lateinit var repository: TranslationRepository
    private lateinit var bubble: BubbleController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var translateJob: Job? = null
    private var root: LinearLayout? = null
    private var suggestion: TextView? = null
    private var clipboardChip: Button? = null
    private var replaceButton: Button? = null
    private var lastResult: TranslationResult? = null
    private var lastRequested = ""
    private var language = "ar"
    private var shifted = false
    private var symbols = false
    private var sensitive = false
    private lateinit var palette: KeyboardPalette
    private lateinit var clipboard: ClipboardManager
    private lateinit var clipboardHistory: ClipboardHistoryManager
    private var activePopup: android.widget.PopupWindow? = null
    private var lastReplacement: ReplaceMemory? = null
    private val clipboardChanged = ClipboardManager.OnPrimaryClipChangedListener {
        captureClipboardChange()
        refreshClipboardChip()
    }
    private data class ReplaceMemory(val source: String, val translated: String)

    private data class KeyboardPalette(
        val background: Int,
        val key: Int,
        val specialKey: Int,
        val activeKey: Int,
        val text: Int,
        val secondaryText: Int,
        val separator: Int
    )

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        repository = TranslationRepository.get(this)
        bubble = BubbleController(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardHistory = ClipboardHistoryManager(this)
        clipboard.addPrimaryClipChangedListener(clipboardChanged)
        captureClipboardChange()
    }

    override fun onCreateInputView(): View = buildKeyboard().also { root = it }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        sensitive = info == null || isSensitive(info)
        if (sensitive) clearTranslation() else refreshClipboardChip()
    }

    private fun isSensitive(info: EditorInfo): Boolean {
        val type = info.inputType
        val inputClass = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val explicitlyPrivate = info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0
        val password = variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_NUMBER_VARIATION_PASSWORD
        )
        // Numeric/phone/date fields do not need translation and may contain PIN or payment data.
        val nonTextSensitive = inputClass == InputType.TYPE_CLASS_NUMBER ||
            inputClass == InputType.TYPE_CLASS_PHONE || inputClass == InputType.TYPE_CLASS_DATETIME
        return explicitlyPrivate || password || nonTextSensitive
    }

    private fun buildKeyboard(): LinearLayout = LinearLayout(this).apply {
        palette = resolvePalette()
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        setPadding(6.dp, 4.dp, 6.dp, 6.dp)
        setBackgroundColor(palette.background)
        if (settings.glassKeyboard) background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF401C25.toInt(), 0xFF41432C.toInt(), 0xFF082F2B.toInt())
        )
        addView(buildSuggestionBar())
        addView(buildToolbarRow())
        if (settings.showSizeControls) addView(LinearLayout(this@FirInputMethodService).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(key("−", special = true) { settings.keyHeight -= 4; rebuild() }, params(44))
            addView(TextView(context).apply { text = "حجم لوحة المفاتيح"; gravity = Gravity.CENTER; setTextColor(palette.secondaryText) }, LinearLayout.LayoutParams(0, 36.dp, 1f))
            addView(key("+", special = true) { settings.keyHeight += 4; rebuild() }, params(44))
        })
        currentRows().forEachIndexed { index, row -> addView(buildRow(row, index)) }
        addView(buildBottomRow())
    }

    private fun buildSuggestionBar() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        setPadding(10.dp, 2.dp, 2.dp, 2.dp)
        setBackgroundColor(if (settings.glassKeyboard) Color.TRANSPARENT else palette.background)
        clipboardChip = key("▣", special = true) { pasteClipboard() }.apply {
            visibility = View.GONE
            textSize = 12f
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        addView(clipboardChip, LinearLayout.LayoutParams(128.dp, 38.dp).apply { setMargins(0, 2.dp, 6.dp, 2.dp) })
        clipboardChip?.setOnLongClickListener { showClipboardHistory(); true }
        suggestion = TextView(context).apply {
            text = "Fir   عربي → English"
            setTextColor(palette.secondaryText)
            textSize = 13f
            maxLines = 2
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
        }
        addView(suggestion, LinearLayout.LayoutParams(0, 42.dp, 1f))
        replaceButton = key("Replace", palette.activeKey, special = true) { replaceCurrent() }.apply { visibility = View.GONE }
        addView(replaceButton, LinearLayout.LayoutParams(76.dp, 38.dp).apply { setMargins(2.dp, 2.dp, 2.dp, 2.dp) })
        addView(key("×", Color.TRANSPARENT, special = true) { clearTranslation() }, LinearLayout.LayoutParams(42.dp, 38.dp))
        post { refreshClipboardChip() }
    }

    private fun buildToolbarRow() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        setPadding(4.dp, 0, 4.dp, 2.dp)
        val toolParams = { LinearLayout.LayoutParams(44.dp, 38.dp).apply { setMargins(3.dp, 2.dp, 3.dp, 2.dp) } }
        addView(key("↶", special = true) { undoLastReplace() }, toolParams())
        addView(key("◀", special = true) { moveCursor(false) }, toolParams())
        addView(key("▶", special = true) { moveCursor(true) }, toolParams())
        addView(key("😀", special = true) { showEmojiPicker() }, toolParams())
    }

    private fun currentRows() = when { symbols -> KeyboardLayout.numbers; language == "ar" -> KeyboardLayout.arabic; else -> KeyboardLayout.english }
    private fun buildRow(chars: List<String>, rowIndex: Int) = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        if (!symbols && language == "en" && rowIndex == 2) {
            addView(key(if (shifted) "⇧" else "⇧", if (shifted) palette.activeKey else palette.specialKey, special = true) { shifted = !shifted; rebuild() }, params(48))
        }
        chars.forEach { ch ->
            addView(
                key(if (shifted && language == "en") ch.uppercase() else ch) { commitKey(ch) },
                LinearLayout.LayoutParams(0, settings.keyHeight.dp, 1f).apply { setMargins(2.dp, 4.dp, 2.dp, 4.dp) }
            )
        }
        if (rowIndex == 2) {
            addView(key("⌫", special = true) { handleBackspace(); typed() }, params(50))
        }
    }
    private fun buildBottomRow() = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        addView(key(if (symbols) "ABC" else "123", special = true) { symbols = !symbols; rebuild() }, params(54))
        addView(key("◉", special = true) { language = if (language == "ar") "en" else "ar"; symbols = false; rebuild() }, params(46))
        addView(key(if (language == "ar") "العربية" else "English") { currentInputConnection?.commitText(" ", 1); typed() }, LinearLayout.LayoutParams(0, settings.keyHeight.dp, 1f).apply { setMargins(3.dp,3.dp,3.dp,3.dp) })
        addView(key(".", special = true) { currentInputConnection?.commitText(".", 1); typed() }, params(42))
        addView(key(if (language == "ar") "إدخال" else "return", palette.activeKey, special = true) { currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)); clearTranslation() }, params(60))
    }

    private fun params(width: Int) = LinearLayout.LayoutParams(width.dp, settings.keyHeight.dp).apply { setMargins(2.dp,4.dp,2.dp,4.dp) }
    private fun key(label: String, color: Int? = null, special: Boolean = false, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = when { label.length == 1 -> 21f; label in listOf("return", "إدخال", "space", "مسافة") -> 11f; else -> 12f }
        typeface = Typeface.create("sans", Typeface.NORMAL)
        if (label == "⇧") { text = "⬆"; textSize = 27f; typeface = Typeface.DEFAULT_BOLD }
        setTextColor(if (settings.glassKeyboard) Color.WHITE else palette.text)
        isAllCaps = false
        includeFontPadding = false
        minWidth = 0
        minimumWidth = 0
        minHeight = 0
        minimumHeight = 0
        stateListAnimator = null
        elevation = if (special) 0.5f.dp else 1.5f.dp
        background = android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x448AB4F8), bg(color ?: if (special) palette.specialKey else palette.key, 9f.dp), null)
        if (settings.glassKeyboard) {
            val blue = label in listOf("return", "إدخال")
            val glassFace = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                if (blue) intArrayOf(0xFF8CCAFF.toInt(), 0xFF2476E7.toInt(), 0xFF70B2FF.toInt())
                else intArrayOf(0xBBDDE4E8.toInt(), 0x555B6670, 0x887D9294.toInt())
            ).apply { cornerRadius = if (blue) 32f.dp else 15f.dp; setStroke(1.dp.coerceAtLeast(1), 0xBBDDFFFF.toInt()) }
            background = android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x66FFFFFF), glassFace, null)
            elevation = 3f.dp
        }
        setSingleLine(true)
        var preview: android.widget.PopupWindow? = null
        var repeatJob: Job? = null
        var repeated = false
        var swiping = false
        var swipeAnchorX = 0f
        val swipeThreshold = 34.dp
        setOnTouchListener { view, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    repeated = false
                    swiping = false
                    swipeAnchorX = event.rawX
                    if (label == "⌫") {
                        repeatJob?.cancel()
                        repeatJob = scope.launch {
                            delay(350)
                            repeated = true
                            while (isActive && view.isAttachedToWindow && isInputViewShown) {
                                click()
                                delay(65)
                            }
                        }
                    }
                    view.animate().scaleX(.96f).scaleY(.94f).setDuration(45).start()
                    if (!special && label.length == 1) {
                        val caption = TextView(context).apply { text = label; textSize = 30f; gravity = Gravity.CENTER; setTextColor(palette.text); background = bg(palette.specialKey, 12f.dp) }
                        preview = android.widget.PopupWindow(caption, 54.dp, 66.dp, false).apply { isClippingEnabled = true }
                        runCatching { preview?.showAsDropDown(view, (view.width - 54.dp) / 2, -view.height - 66.dp) }
                    }
                }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                    repeatJob?.cancel(); repeatJob = null
                    preview?.dismiss(); preview = null
                    view.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (label == "⌫" && kotlin.math.abs(event.rawX - swipeAnchorX) > swipeThreshold) {
                        repeatJob?.cancel(); repeatJob = null
                        preview?.dismiss(); preview = null
                        swiping = true
                        swipeAnchorX = event.rawX
                        deleteWordBackward()
                        feedback()
                    }
                    if (event.x < 0 || event.x >= view.width || event.y < 0 || event.y >= view.height) {
                        repeatJob?.cancel(); repeatJob = null
                    }
                }
            }
            false
        }
        addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) {}
            override fun onViewDetachedFromWindow(v: View) { repeatJob?.cancel(); repeatJob = null; preview?.dismiss(); preview = null }
        })
        setPadding(1.dp, 0, 1.dp, 0)
        setOnClickListener { if (label != "⌫" || (!repeated && !swiping)) { feedback(); click() } }
    }
    private fun commitKey(raw: String) { val out = if (shifted && language == "en") raw.uppercase() else raw; currentInputConnection?.commitText(out, 1); if (shifted) shifted = false; lastReplacement = null; typed() }
    private fun typed() = scheduleTranslation(false)

    private fun scheduleTranslation(immediate: Boolean) {
        if (sensitive) return
        translateJob?.cancel()
        translateJob = scope.launch {
            if (!immediate) delay(settings.delay.millis)
            val source = currentSegment()
            if (source == lastRequested || !repository.isWorthTranslating(source)) { if (source.isBlank()) clearTranslation(); return@launch }
            lastRequested = source
            try {
                val result = withContext(Dispatchers.Default) { repository.translate(source, settings.direction) }
                if (currentSegment() == source) showTranslation(result)
            } catch (_: Exception) {
                suggestion?.text = "Offline translation model required"
                replaceButton?.visibility = View.GONE
            }
        }
    }

    private fun currentSegment(): String {
        val before = currentInputConnection?.getTextBeforeCursor(500, 0)?.toString().orEmpty()
        return before.substringAfterLast('\n').trimStart()
    }
    private fun showTranslation(result: TranslationResult) {
        lastResult = result; suggestion?.text = result.translated; replaceButton?.visibility = View.VISIBLE; clipboardChip?.visibility = View.GONE
        if (settings.bubbleEnabled && bubble.canShow()) bubble.show(result.translated, ::replaceCurrent) { copy(result.translated) }
    }
    private fun replaceCurrent() {
        val result = lastResult ?: return
        currentInputConnection?.run {
            beginBatchEdit()
            deleteSurroundingText(result.source.length, 0)
            commitText(result.translated, 1)
            endBatchEdit()
        }
        lastReplacement = ReplaceMemory(result.source, result.translated)
        clearTranslation()
    }
    private fun undoLastReplace() {
        val memory = lastReplacement ?: return
        currentInputConnection?.run {
            beginBatchEdit()
            deleteSurroundingText(memory.translated.length, 0)
            commitText(memory.source, 1)
            endBatchEdit()
        }
        lastReplacement = null
        typed()
    }
    private fun moveCursor(forward: Boolean) {
        lastReplacement = null
        val code = if (forward) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
    private fun deleteWordBackward() {
        lastReplacement = null
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) { ic.commitText("", 1); return }
        val before = ic.getTextBeforeCursor(64, 0)?.toString()
        if (before.isNullOrEmpty()) return
        var idx = before.length
        while (idx > 0 && before[idx - 1].isWhitespace()) idx--
        while (idx > 0 && !before[idx - 1].isWhitespace()) idx--
        val deleteCount = (before.length - idx).coerceAtLeast(1)
        ic.deleteSurroundingText(deleteCount, 0)
    }
    private val commonEmojis = listOf(
        "😀", "😂", "🥰", "😍", "😅", "😊", "🙂", "😉", "😎", "🤔",
        "😢", "😭", "😡", "👍", "👎", "🙏", "👏", "💪", "🔥", "❤️",
        "💔", "🎉", "✅", "❌", "⭐", "☀️", "🌙", "⚽", "🏆", "👀"
    )
    private fun showEmojiPicker() {
        val anchor = root ?: return
        val grid = android.widget.GridLayout(this).apply {
            columnCount = 6
            setPadding(8.dp, 8.dp, 8.dp, 8.dp)
        }
        commonEmojis.forEach { emoji ->
            grid.addView(TextView(this).apply {
                text = emoji
                textSize = 24f
                gravity = Gravity.CENTER
                setOnClickListener { currentInputConnection?.commitText(emoji, 1); lastReplacement = null; typed() }
            }, android.widget.GridLayout.LayoutParams().apply { width = 48.dp; height = 48.dp })
        }
        val panel = android.widget.ScrollView(this).apply {
            addView(grid)
            background = bg(palette.background, 14f.dp)
            elevation = 6f.dp
        }
        activePopup?.dismiss()
        val popupHeight = 220.dp
        activePopup = android.widget.PopupWindow(panel, anchor.width - 24.dp, popupHeight, true).apply {
            isOutsideTouchable = true
            showAsDropDown(anchor, 12.dp, -(anchor.height + popupHeight + 8.dp))
        }
    }
    private fun copy(text: String) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Fir translation", text)); bubble.hide() }
    private fun clearTranslation() { translateJob?.cancel(); lastResult = null; lastRequested = ""; suggestion?.text = "Fir • ${if (language == "ar") "عربي → English" else "English → عربي"}"; replaceButton?.visibility = View.GONE; bubble.hide(); refreshClipboardChip() }

    private fun refreshClipboardChip() {
        val chip = clipboardChip ?: return
        if (sensitive || !clipboard.hasPrimaryClip()) {
            chip.visibility = View.GONE
            return
        }
        val clip = clipboard.primaryClip ?: run { chip.visibility = View.GONE; return }
        val item = clip.getItemAt(0)
        val text = item.text?.toString()?.trim().orEmpty()
        val isImage = item.uri != null && clip.description.hasMimeType("image/*")
        chip.text = when {
            text.isNotEmpty() -> "▣  " + text.replace(Regex("\\s+"), " ").take(18)
            isImage -> "▣  لقطة شاشة"
            else -> { chip.visibility = View.GONE; return }
        }
        chip.visibility = if (lastResult == null) View.VISIBLE else View.GONE
    }

    private fun pasteClipboard() {
        if (sensitive) return
        val clip = clipboard.primaryClip ?: return
        val item = clip.getItemAt(0)
        val text = item.text?.toString()
        if (!text.isNullOrEmpty()) {
            currentInputConnection?.commitText(text, 1)
            typed()
            return
        }
        val uri = item.uri ?: return
        val description = clip.description
        val mime = (0 until description.mimeTypeCount)
            .map(description::getMimeType)
            .firstOrNull { ClipDescription.compareMimeTypes(it, "image/*") }
            ?: contentResolver.getType(uri)
            ?: return
        val accepted = currentInputEditorInfo?.contentMimeTypes.orEmpty()
            .any { ClipDescription.compareMimeTypes(mime, it) }
        if (!accepted) {
            suggestion?.text = "هذا الحقل لا يقبل لصق الصور مباشرة"
            return
        }
        val content = InputContentInfo(uri, ClipDescription(description), null)
        val inserted = runCatching {
            currentInputConnection?.commitContent(
                content,
                InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,
                null
            ) == true
        }.getOrDefault(false)
        suggestion?.text = if (inserted) "تم لصق الصورة" else "تعذر لصق الصورة هنا"
    }
    private fun handleBackspace() {
        lastReplacement = null
        val ic = currentInputConnection ?: return
        // deleteSurroundingText only removes characters around the cursor and ignores
        // an active selection, which is why deleting a highlighted word did nothing.
        // If text is selected, replace it with an empty string instead.
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
    }

    private fun captureClipboardChange() {
        if (sensitive) return
        val clip = clipboard.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).text?.toString()
        if (!text.isNullOrBlank()) clipboardHistory.add(text)
    }

    private fun showClipboardHistory() {
        if (sensitive) return
        val anchor = root ?: return
        val pinned = clipboardHistory.pinned()
        val items = clipboardHistory.all()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(10.dp, 10.dp, 10.dp, 10.dp)
        }
        val panel = android.widget.ScrollView(this).apply {
            addView(container)
            background = bg(palette.background, 14f.dp)
            elevation = 6f.dp
        }
        fun sectionLabel(text: String) = TextView(this).apply {
            this.text = text
            setTextColor(palette.secondaryText)
            textSize = 11f
            setPadding(4.dp, 6.dp, 4.dp, 2.dp)
        }
        fun row(text: String, starFilled: Boolean, onStar: () -> Unit, onDelete: () -> Unit) = LinearLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(6.dp, 8.dp, 6.dp, 8.dp)
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(0x338AB4F8), null, null
            )
            addView(TextView(this@FirInputMethodService).apply {
                this.text = text
                setTextColor(palette.text)
                textSize = 13f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(this@FirInputMethodService).apply {
                this.text = if (starFilled) "★" else "☆"
                setTextColor(if (starFilled) 0xFFE0A030.toInt() else palette.secondaryText)
                textSize = 15f
                setPadding(10.dp, 0, 10.dp, 0)
                setOnClickListener { onStar() }
            })
            addView(TextView(this@FirInputMethodService).apply {
                this.text = "✕"
                setTextColor(palette.secondaryText)
                textSize = 15f
                setPadding(4.dp, 0, 4.dp, 0)
                setOnClickListener { onDelete() }
            })
            setOnClickListener {
                currentInputConnection?.commitText(text, 1)
                typed()
                activePopup?.dismiss()
            }
        }
        if (pinned.isEmpty() && items.isEmpty()) {
            container.addView(TextView(this).apply {
                text = "لا توجد عناصر منسوخة بعد"
                setTextColor(palette.secondaryText)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(8.dp, 18.dp, 8.dp, 18.dp)
            })
        } else {
            if (pinned.isNotEmpty()) {
                container.addView(sectionLabel("مثبّت"))
                pinned.forEach { item ->
                    container.addView(row(item, starFilled = true,
                        onStar = { clipboardHistory.togglePin(item); activePopup?.dismiss(); showClipboardHistory() },
                        onDelete = { clipboardHistory.removePinned(item); activePopup?.dismiss(); showClipboardHistory() }
                    ))
                }
            }
            if (items.isNotEmpty()) {
                container.addView(sectionLabel("الأخيرة"))
                items.forEach { item ->
                    container.addView(row(item, starFilled = false,
                        onStar = { clipboardHistory.togglePin(item); activePopup?.dismiss(); showClipboardHistory() },
                        onDelete = { clipboardHistory.remove(item); activePopup?.dismiss(); showClipboardHistory() }
                    ))
                }
                container.addView(TextView(this).apply {
                    text = "مسح الأخيرة"
                    setTextColor(0xFFE0524D.toInt())
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setPadding(0, 12.dp, 0, 4.dp)
                    setOnClickListener {
                        clipboardHistory.clear()
                        activePopup?.dismiss()
                    }
                })
            }
        }
        activePopup?.dismiss()
        val popupHeight = 300.dp
        activePopup = android.widget.PopupWindow(
            panel, anchor.width - 24.dp, popupHeight, true
        ).apply {
            isOutsideTouchable = true
            showAsDropDown(anchor, 12.dp, -(anchor.height + popupHeight + 8.dp))
        }
    }

    private fun rebuild() { setInputView(buildKeyboard().also { root = it }); clearTranslation() }
    private fun feedback() {
        if (settings.vibration) runCatching {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(12, 35))
                else @Suppress("DEPRECATION") vibrator.vibrate(12)
            }
        }
        if (settings.sound) runCatching {
            (getSystemService(AUDIO_SERVICE) as AudioManager).playSoundEffect(AudioManager.FX_KEY_CLICK, 0.18f)
        }
    }
    private fun bg(color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun resolvePalette(): KeyboardPalette {
        val systemDark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        val dark = settings.theme == com.fir.translate.core.ThemeMode.DARK ||
            settings.theme == com.fir.translate.core.ThemeMode.SYSTEM && systemDark
        return if (dark) KeyboardPalette(
            background = 0xFF1C1C1E.toInt(), key = 0xFF5A5A5E.toInt(), specialKey = 0xFF3A3A3C.toInt(),
            activeKey = 0xFF2D8C8F.toInt(), text = Color.WHITE, secondaryText = 0xFFE5E5EA.toInt(), separator = 0xFF2C2C2E.toInt()
        ) else KeyboardPalette(
            background = 0xFFD1D5DB.toInt(), key = 0xFFFDFDFE.toInt(), specialKey = 0xFFAEB3BC.toInt(),
            activeKey = 0xFF57D2D1.toInt(), text = 0xFF111111.toInt(), secondaryText = 0xFF3A3A3C.toInt(), separator = 0xFFB8BDC5.toInt()
        )
    }
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    private val Float.dp get() = this * resources.displayMetrics.density
    override fun onFinishInputView(finishingInput: Boolean) { activePopup?.dismiss(); clearTranslation(); super.onFinishInputView(finishingInput) }
    override fun onDestroy() { activePopup?.dismiss(); clipboard.removePrimaryClipChangedListener(clipboardChanged); scope.cancel(); bubble.hide(); super.onDestroy() }
}
