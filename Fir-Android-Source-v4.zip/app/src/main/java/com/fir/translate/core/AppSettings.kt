package com.fir.translate.core

import android.content.Context

enum class Direction { AUTO, AR_EN, EN_AR }
enum class Delay(val millis: Long) { FAST(300), BALANCED(450), RELAXED(600) }
enum class ThemeMode { SYSTEM, LIGHT, DARK }

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("fir_settings", Context.MODE_PRIVATE)
    var direction: Direction
        get() = enumValueOf(prefs.getString("direction", Direction.AUTO.name)!!)
        set(v) = prefs.edit().putString("direction", v.name).apply()
    var delay: Delay
        get() = enumValueOf(prefs.getString("delay", Delay.BALANCED.name)!!)
        set(v) = prefs.edit().putString("delay", v.name).apply()
    var bubbleEnabled: Boolean
        get() = prefs.getBoolean("bubble", false)
        set(v) = prefs.edit().putBoolean("bubble", v).apply()
    var vibration: Boolean
        get() = prefs.getBoolean("vibration", true)
        set(v) = prefs.edit().putBoolean("vibration", v).apply()
    var sound: Boolean
        get() = prefs.getBoolean("sound", false)
        set(v) = prefs.edit().putBoolean("sound", v).apply()
    var theme: ThemeMode
        get() = enumValueOf(prefs.getString("theme", ThemeMode.SYSTEM.name)!!)
        set(v) = prefs.edit().putString("theme", v.name).apply()
    var onboardingDone: Boolean
        get() = prefs.getBoolean("onboarding", false)
        set(v) = prefs.edit().putBoolean("onboarding", v).apply()
}
