package com.fir.translate.translation

import android.content.Context
import com.fir.translate.core.Direction
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.LinkedHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class ModelStatus { REQUIRED, DOWNLOADING, READY, FAILED }
data class TranslationResult(val source: String, val translated: String, val direction: Direction)

class TranslationRepository private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val arEn = translator(TranslateLanguage.ARABIC, TranslateLanguage.ENGLISH)
    private val enAr = translator(TranslateLanguage.ENGLISH, TranslateLanguage.ARABIC)
    private val cache = object : LinkedHashMap<String, String>(40, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 40
    }
    private val _status = MutableStateFlow(ModelStatus.REQUIRED)
    val status: StateFlow<ModelStatus> = _status

    private fun translator(source: String, target: String): Translator = Translation.getClient(
        TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
    )

    fun detectDirection(text: String, preference: Direction): Direction {
        if (preference != Direction.AUTO) return preference
        val arabic = text.count { it in '\u0600'..'\u06FF' }
        val latin = text.count { it in 'A'..'Z' || it in 'a'..'z' }
        return if (arabic >= latin) Direction.AR_EN else Direction.EN_AR
    }

    fun isWorthTranslating(text: String): Boolean {
        val clean = text.trim()
        return clean.length >= 2 && clean.any(Char::isLetter) && clean.any { it.isWhitespace() } || clean.length >= 3 && clean.count(Char::isLetter) >= 2
    }

    suspend fun downloadModels(): Result<Unit> {
        _status.value = ModelStatus.DOWNLOADING
        val conditions = DownloadConditions.Builder().build()
        return runCatching {
            awaitTask(arEn.downloadModelIfNeeded(conditions))
            awaitTask(enAr.downloadModelIfNeeded(conditions))
            _status.value = ModelStatus.READY
        }.onFailure { _status.value = ModelStatus.FAILED }
    }

    suspend fun translate(text: String, preference: Direction): TranslationResult {
        val source = text.trim()
        require(isWorthTranslating(source))
        val direction = detectDirection(source, preference)
        val key = "${direction.name}:$source"
        synchronized(cache) { cache[key] }?.let { return TranslationResult(source, it, direction) }
        val client = if (direction == Direction.AR_EN) arEn else enAr
        val translated = awaitTask(client.translate(source))
        synchronized(cache) { cache[key] = translated }
        return TranslationResult(source, translated, direction)
    }

    fun markReady() { _status.value = ModelStatus.READY }

    private suspend fun <T> awaitTask(task: com.google.android.gms.tasks.Task<T>): T =
        suspendCancellableCoroutine { continuation ->
            task.addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
                .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
        }

    companion object {
        @Volatile private var instance: TranslationRepository? = null
        fun get(context: Context) = instance ?: synchronized(this) {
            instance ?: TranslationRepository(context).also { instance = it }
        }
    }
}
