package com.fir.translate.keyboard

object KeyboardLayout {
    val arabic = listOf(
        listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج","د"),
        listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"),
        listOf("ئ","ء","ؤ","ر","لا","ى","ة","و","ز","ظ")
    )
    val english = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("z","x","c","v","b","n","m")
    )
    val numbers = listOf(
        listOf("1","2","3","4","5","6","7","8","9","0"),
        listOf("@","#","$","%","&","-","+","(",")","/"),
        listOf("*","\"","'",":",";","!","?",",",".")
    )
}
