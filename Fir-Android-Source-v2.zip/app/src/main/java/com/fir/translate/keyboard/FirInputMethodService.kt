package com.fir.translate.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.fir.translate.core.AppSettings
import com.fir.translate.overlay.BubbleController
import com.fir.translate.translation.TranslationRepository
import com.fir.translate.translation.TranslationResult
import kotlinx.coroutines.*

class FirInputMethodService : InputMethodService() {
    private lateinit var settings: AppSettings
    private lateinit var repository: TranslationRepository
    private lateinit var bubble: BubbleController
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var translateJob: Job? = null
    private var root: LinearLayout? = null
    private var suggestion: TextView? = null
    private var replaceButton: Button? = null
    private var lastResult: TranslationResult? = null
    private var lastRequested = ""
    private var language = "ar"
    private var shifted = false
    private var symbols = false
    private var sensitive = false

    override fun onCreate() {
        super.onCreate(); settings = AppSettings(this); repository = TranslationRepository.get(this); bubble = BubbleController(this)
    }

    override fun onCreateInputView(): View = buildKeyboard().also { root = it }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        sensitive = info == null || isSensitive(info)
        if (sensitive) clearTranslation()
    }

    private fun isSensitive(info: EditorInfo): Boolean {
        val type = info.inputType
        val inputClass = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION
        val explicitlyPrivate = info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0
        val password = variation in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD, InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, InputType.TYPE_NUMBER_VARIATION_PASSWORD
        )
        // Numeric/phone/date fields do not need translation and may contain PIN or payment data.
        val nonTextSensitive = inputClass == InputType.TYPE_CLASS_NUMBER ||
            inputClass == InputType.TYPE_CLASS_PHONE || inputClass == InputType.TYPE_CLASS_DATETIME
        return explicitlyPrivate || password || nonTextSensitive
    }

    private fun buildKeyboard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 10); setBackgroundColor(0xFF071014.toInt())
        addView(buildSuggestionBar())
        currentRows().forEach { addView(buildRow(it)) }
        addView(buildBottomRow())
    }

    private fun buildSuggestionBar() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL; setPadding(12, 4, 4, 4); background = bg(0xFF102126.toInt(), 20f)
        suggestion = TextView(context).apply { text = "Fir • عربي → English"; setTextColor(0xFFB5C9CE.toInt()); textSize = 14f; maxLines = 2 }
        addView(suggestion, LinearLayout.LayoutParams(0, 58.dp, 1f))
        replaceButton = key("Replace", 0xFF163C40.toInt()) { replaceCurrent() }.apply { visibility = View.GONE }
        addView(replaceButton, LinearLayout.LayoutParams(84.dp, 48.dp))
        addView(key("×", Color.TRANSPARENT) { clearTranslation() }, LinearLayout.LayoutParams(48.dp, 48.dp))
    }

    private fun currentRows() = when { symbols -> KeyboardLayout.numbers; language == "ar" -> KeyboardLayout.arabic; else -> KeyboardLayout.english }
    private fun buildRow(chars: List<String>) = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        chars.forEach { ch -> addView(key(if (shifted && language == "en") ch.uppercase() else ch) { commitKey(ch) }, LinearLayout.LayoutParams(0, 50.dp, 1f).apply { setMargins(2,2,2,2) }) }
    }
    private fun buildBottomRow() = LinearLayout(this).apply {
        gravity = Gravity.CENTER
        addView(key(if (symbols) "ABC" else "123") { symbols = !symbols; rebuild() }, params(58))
        addView(key(if (language == "ar") "EN" else "ع") { language = if (language == "ar") "en" else "ar"; symbols = false; rebuild() }, params(54))
        addView(key("⇧") { if (language == "en") { shifted = !shifted; rebuild() } }, params(48))
        addView(key("Fir", 0xFF163C40.toInt()) { scheduleTranslation(true) }, params(58))
        addView(key("Space") { currentInputConnection?.commitText(" ", 1); typed() }, LinearLayout.LayoutParams(0, 52.dp, 1f).apply { setMargins(2,2,2,2) })
        addView(key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0); typed() }, params(52))
        addView(key("↵") { currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER)); clearTranslation() }, params(52))
    }

    private fun params(width: Int) = LinearLayout.LayoutParams(width.dp, 52.dp).apply { setMargins(2,2,2,2) }
    private fun key(label: String, color: Int = 0xFF18272C.toInt(), click: () -> Unit) = Button(this).apply {
        text = label; textSize = if (label.length == 1) 18f else 12f; setTextColor(Color.WHITE); isAllCaps = false; minWidth = 0; minimumWidth = 0
        background = bg(color, 16f); setPadding(1,0,1,0); setOnClickListener { haptic(); click() }
    }
    private fun commitKey(raw: String) { val out = if (shifted && language == "en") raw.uppercase() else raw; currentInputConnection?.commitText(out, 1); if (shifted) shifted = false; typed() }
    private fun typed() = scheduleTranslation(false)

    private fun scheduleTranslation(immediate: Boolean) {
        if (sensitive) return
        translateJob?.cancel()
        translateJob = scope.launch {
            if (!immediate) delay(settings.delay.millis)
            val source = currentSegment()
            if (source == lastRequested || !repository.isWorthTranslating(source)) { if (source.isBlank()) clearTranslation(); return@launch }
            lastRequested = source
            try {
                val result = withContext(Dispatchers.Default) { repository.translate(source, settings.direction) }
                if (currentSegment() == source) showTranslation(result)
            } catch (_: Exception) {
                suggestion?.text = "Offline translation model required"
                replaceButton?.visibility = View.GONE
            }
        }
    }

    private fun currentSegment(): String {
        val before = currentInputConnection?.getTextBeforeCursor(500, 0)?.toString().orEmpty()
        return before.substringAfterLast('\n').trimStart()
    }
    private fun showTranslation(result: TranslationResult) {
        lastResult = result; suggestion?.text = result.translated; replaceButton?.visibility = View.VISIBLE
        if (settings.bubbleEnabled && bubble.canShow()) bubble.show(result.translated, ::replaceCurrent) { copy(result.translated) }
    }
    private fun replaceCurrent() {
        val result = lastResult ?: return
        currentInputConnection?.run {
            beginBatchEdit()
            deleteSurroundingText(result.source.length, 0)
            commitText(result.translated, 1)
            endBatchEdit()
        }
        clearTranslation()
    }
    private fun copy(text: String) { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Fir translation", text)); bubble.hide() }
    private fun clearTranslation() { translateJob?.cancel(); lastResult = null; lastRequested = ""; suggestion?.text = "Fir • ${if (language == "ar") "عربي → English" else "English → عربي"}"; replaceButton?.visibility = View.GONE; bubble.hide() }
    private fun rebuild() { setInputView(buildKeyboard().also { root = it }); clearTranslation() }
    private fun haptic() { if (!settings.vibration) return; val v = getSystemService(VIBRATOR_SERVICE) as Vibrator; if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(12, 35)) else @Suppress("DEPRECATION") v.vibrate(12) }
    private fun bg(color: Int, radius: Float) = android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()
    override fun onFinishInputView(finishingInput: Boolean) { clearTranslation(); super.onFinishInputView(finishingInput) }
    override fun onDestroy() { scope.cancel(); bubble.hide(); super.onDestroy() }
}
